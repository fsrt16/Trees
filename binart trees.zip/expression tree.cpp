#include<iostream>
#include<cstring>
using namespace std;
struct node
{
	char data;
	node *left;
	node *right;
}*s[20],*root=NULL;
int top=-1;
void push(node*t)
{
	top++;
	s[top]=t;
}
node *pop()
{
	top--;
	return s[top+1];
}
bool isoperator(char C)

{

	if(C == '+' || C == '-' || C == '*' || C == '/' || C== '$')

		return true;


    else
	return false;

}
int main()
{
int i=0;
char post[20];
cout<<"Enter the postfix expression ";
cin.getline(post,20);
for(i=0;i<strlen(post);i++)
{
	if(isoperator(post[i]))
	{
		node *t=new node;
		t->data=post[i];
		node*a=pop();
		node*b=pop();
		t->left=b;
		t->right=a;
		push(t);
	}
	else
	{
		node*t=new node;
		t->data=post[i];
		t->left=NULL;
		t->right=NULL;
		push(t);
	}
}
root=s[top];
}
